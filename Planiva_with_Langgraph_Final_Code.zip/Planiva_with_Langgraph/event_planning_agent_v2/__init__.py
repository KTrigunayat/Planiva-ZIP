"""
Event Planning Agent v2 - Modernized with CrewAI, LangGraph, and MCP
"""

__version__ = "2.0.0"
__author__ = "Event Planning Team"
__description__ = "AI-powered event planning system with multi-agent collaboration"